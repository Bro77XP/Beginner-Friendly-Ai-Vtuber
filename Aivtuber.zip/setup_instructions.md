# VTube Studio Animation Setup Instructions

This file provides step-by-step instructions for configuring VTube Studio animations for the AI VTuber.

## Overview

The AI VTuber script automatically detects and maps VTube Studio hotkeys to emotion-based animations. You need to:

1. Create animations in VTube Studio
2. Assign hotkeys to those animations
3. Configure the hotkey IDs in the `EMOTION_HOTKEYS` dictionary

## Step-by-Step Setup

### Step 1: Create Animations in VTube Studio

1. Open VTube Studio
2. Select your character model
3. Go to the "Animation" or "Hotkey" tab
4. Create 5 new animations with descriptive names:
   - Happy animation (e.g., "happy", "joyful", "smile")
   - Sad animation (e.g., "sad", "cry", "depress")
   - Angry animation (e.g., "angry", "mad", "upset")
   - Thinking animation (e.g., "think", "hmm", "idea")
   - Neutral animation (e.g., "neutral", "calm", "default")

### Step 2: Assign Hotkeys

1. Select each animation
2. Assign a unique hotkey (keyboard shortcut) to each animation
3. Test each hotkey to ensure they work

### Step 3: Identify Hotkey IDs

There are multiple ways to find the hotkey IDs:

#### Method 1: Using VTube Studio's API
1. Open VTube Studio
2. Press F12 to open Developer Tools
3. Go to Network tab
4. Look for requests to `http://localhost:8001`
5. Find the "HotkeysInCurrentModelRequest" response
6. Extract the hotkeyID values

#### Method 2: Using VTube Studio's Debug Info
1. Open VTube Studio
2. Press Ctrl+Shift+I to open Developer Tools
3. Go to Console tab
4. Enter this command:
```javascript
fetch('http://localhost:8001', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    apiName: "VTubeStudioPublicAPI",
    apiVersion: "1.0",
    requestID: "get_hotkeys",
    messageType: "HotkeysInCurrentModelRequest"
  })
})
.then(r => r.json())
.then(d => console.log(JSON.stringify(d.data.availableHotkeys)))
```

#### Method 3: Simple Copy-Paste
1. Open VTube Studio
2. Click on "Plugin" or "Extensions" menu
3. Select "Local AI VTuber" or similar
4. Look for hotkey information or debug output

### Step 4: Configure Hotkey IDs

Open `Aivtuber.py` and update the `EMOTION_HOTKEYS` dictionary:

```python
EMOTION_HOTKEYS = {
    "happy": "your_happy_hotkey_id",    # e.g., "35e965fc477342888a9c6beb2464b12d"
    "sad": "your_sad_hotkey_id",        # e.g., "135ec454ec524d8c8d7c90a20bbc915d"
    "angry": "your_angry_hotkey_id",    # e.g., "f9c5528eab6a4b1cb1189356c4d6a967"
    "thinking": "your_thinking_hotkey_id", # e.g., "abc123..."
    "neutral": "your_neutral_hotkey_id", # e.g., "def456..."
}
```

### Step 5: Test the Setup

1. Run the VTuber script:
```bash
python Aivtuber.py
```

2. You should see:
   - VTS authentication
   - Auto-mapping of hotkeys to emotions
   - Animation triggering when responding to users

## Auto-Configuration Help

If you want to use auto-configuration (the script maps hotkeys based on name patterns), leave the `EMOTION_HOTKEYS` values empty:

```python
EMOTION_HOTKEYS = {
    "happy": "",      # Leave empty for auto-detection
    "sad": "",
    "angry": "",
    "thinking": "",
    "neutral": "",
}
```

The script will automatically match hotkey names to emotions:
- Names containing "happy", "joy", "smile" → happy animation
- Names containing "sad", "cry", "depress" → sad animation
- Names containing "angry", "mad", "upset" → angry animation
- Names containing "think", "hmm", "idea" → thinking animation
- Names containing "neutral", "calm", "default" → neutral animation

## Troubleshooting

### Issue: No animations trigger
**Solution:**
1. Verify VTube Studio is running
2. Check that the plugin "Local AI VTuber" is enabled
3. Ensure animations are properly configured in VTube Studio
4. Verify microphone permissions are granted

### Issue: Only mouth sync works
**Solution:**
1. Mouth sync should work even without VTS animations
2. Check if VTS is properly authenticated
3. Verify VTS_PORT (8001) is correct in VTube Studio settings

### Issue: Script crashes on startup
**Solution:**
1. Check if VTube Studio is running
2. Verify network connectivity
3. Check for firewall issues
4. Restart VTube Studio and the script

## Quick Test Script

Create a test script `test_vts_setup.py`:

```python
import websocket
import json
import time

ws = websocket.WebSocketApp("ws://localhost:8001",
                            on_message=lambda ws, msg: print(f"Response: {msg}"),
                            on_error=lambda ws, err: print(f"Error: {err}"))

ws.run_forever()
```

Run this to test VTube Studio connection before running the main script.

## Alternative: Manual Setup

If auto-configuration doesn't work, you can manually set up the hotkeys:

1. Run `python Aivtuber.py`
2. Wait for hotkeys to be listed
3. Note the hotkey names and IDs
4. Manually update `EMOTION_HOTKEYS` based on your configuration

## Support

For issues with VTube Studio setup:
1. Check VTube Studio documentation
2. Visit VTube Studio forums
3. Check the VTube Studio Discord server

## Files Modified

- `Aivtuber.py` - Main script with VTS integration
- `README.md` - Updated with setup instructions
- `setup_instructions.md` - This setup guide