# AI VTuber - Complete Implementation Summary

## Overview
A comprehensive AI VTuber that uses **RVC (Retrieval-Based Voice Conversion)** for true voice cloning, **Whisper** for speech-to-text, and **Ollama** for AI responses, with continuous listening and VTube Studio integration.

## Key Features

### 🎤 Voice Technology
- **RVC Voice Cloning**: True voice cloning from reference audio
- **Default Voice**: Built-in voice options
- **Voice Parameter**: `--voice <directory>` for custom voice models
- **Automatic Voice Loading**: RVC model directory validation

### 🗣️ Speech & Audio Processing
- **Whisper STT**: Real-time speech-to-text in English
- **RVC Voice Conversion**: Convert TTS to target voice
- **Professional Mouth Sync**: Precise timing with exponential smoothing
- **Advanced Audio Normalization**: Consistent RMS levels

### 🤖 AI & Integration
- **Ollama LLM**: llama3.2 for natural responses
- **VTube Studio**: Animation control and mouth sync
- **Emotion Detection**: Detect emotions from responses
- **Auto-configuration**: Hotkey mapping and setup

### 🎮 User Interface
- **Command-line Arguments**: `--voice`, `--whisper-model`, etc.
- **Rich Console Output**: Color-coded status messages
- **Real-time Visualization**: Mouth sync progress
- **Error Handling**: Graceful fallbacks and recovery

## System Architecture

```
┌─────────────────┐    ┌──────────────┐    ┌─────────────────┐
│   Microphone    │    │   Whisper    │    │   Ollama        │
│   (Listening)   │    │   (STT)      │    │   (LLM Response)│
└─────────────────┘    └──────────────┘    └─────────────────┘
         │                       │                       │
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌──────────────┐    ┌─────────────────┐
│   RVC Voice     │    │  Chatterbox  │    │  Voice Converter │
│   Converter     │    │   TTS        │    │   (for fallback)   │
└─────────────────┘    └──────────────┘    └─────────────────┘
         │                       │                       │
         └───────────┬─────────────┘
                     ▼
             ┌─────────────────┐
             │  Audio Output   │
             │ (Mouth Sync)    │
             └─────────────────┘
```

## Installation

### 1. Install Dependencies
```bash
# Install all dependencies including RVC
pip install -r requirements.txt

# OR install RVC components separately
pip install torch torchaudio librosa soundfile numpy scipy onnxruntime onnx fairseq pyworld praat-parselmouth TTS

# Install VTS components
pip install websocket-client sounddevice pyaudio rich

# Install STT and LLM
pip install openai-whisper ollama
```

### 2. Download Models
```bash
# Pull Whisper model
pip install openai-whisper

# Download RVC model (example)
# Visit https://github.com/RVC-SFT/SVS to find and download RVC models

# Optional: Chatterbox TTS (for fallback)
pip install chatterbox-tts
```

### 3. Set Up VTube Studio
1. Install VTube Studio: https://vts.place/
2. Open plugin "Local AI VTuber"
3. Configure animations and hotkeys
4. Save authentication token

### 4. Download Voice Model (RVC)
```bash
# Example for Chinese singing model (https://github.com/RVC-SFT/SVS)
git clone https://github.com/RVC-SFT/SVS
# Follow README instructions to download and set up model
```

## Running the VTuber

### Basic Usage
```bash
# Use default voice (Chatterbox as fallback)
python Aivtuber.py

# Use custom RVC voice (RVC takes precedence)
python Aivtuber.py --voice /path/to/rvc/model/directory

# Specify Whisper model
python Aivtuber.py --whisper-model medium

# Specify RVC voice directory
python Aivtuber.py --voice ./models/singing_model
```

### Voice Model Directory Structure
Your RVC voice directory should contain:
```
my_voice_model/
├── infer.py              # RVC inference script
├── config.json           # Model configuration
├├── model.pth            # Main model file
├── units.txt            # Phone set
├── phone2id.txt         
├── s3index.bin          # Index for quick lookup
└── scripts/
    └── inference.py
```

## Voice Configuration

### 1. Default Voice
```bash
# Uses built-in Chatterbox TTS voice
python Aivtuber.py
```

### 2. Custom RVC Voice
```bash
# Directory with RVC model files
python Aivtuber.py --voice ./my_voice_model
```

### 3. RVC Setup
1. Download RVC model from https://github.com/RVC-SFT/SVS
2. Extract to desired directory
3. Follow the README instructions in the repository
4. Provide the directory path to `--voice` argument

## Emotion Mapping

The VTuber automatically detects emotions from AI responses:

| Emotion | Detection Keywords | VTS Action |
|---------|-------------------|-------------|
| **Happy** | happy, joy, love, fun, yay | Happy animation hotkey |
| **Sad** | sad, sorry, lonely, cry | Sad animation hotkey |
| **Angry** | angry, mad, hate, shut up | Angry animation hotkey |
| **Thinking** | think, hmm, maybe, idea | Thinking animation hotkey |
| **Neutral** | calm, default, normal | Neutral animation hotkey |

### Manual Configuration
You can manually configure hotkey IDs in `Aivtuber.py`:

```python
EMOTION_HOTKEYS = {
    "happy": "your_happy_hotkey_id",
    "sad": "your_sad_hotkey_id",
   
    "angry": "your_angry_hotkey_id",
    "thinking": "your_thinking_hotkey_id",
    "neutral": "your_neutral_hotkey_id",
}
```

### Auto-Configuration
The VTuber automatically maps VTS hotkeys to emotions based on their names:
- Hotkey names containing "happy", "joy", "smile" → happy emotion
- Hotkey names containing "sad", "cry", "depress" → sad emotion
- Hotkey names containing "angry", "mad", "upset" → angry emotion
- Hotkey names containing "think", "hmm", "idea" → thinking emotion
- Hotkey names containing "neutral", "calm", "default" → neutral emotion

## Mouth Sync

### How It Works
The mouth sync uses **exponential smoothing** for smooth, responsive animations:

1. **Calculate RMS Energy**: For each audio block
2. **Exponential Smoothing**: Combine current and previous values
3. **Update VTS Mouth**: Send smooth values to VTube Studio
4. **Precise Timing**: Sleep to match audio playback rate

```python
# Exponential smoothing example
rms = np.sqrt(np.mean(audio_block ** 2))
smoothed_amp = prev_amp * (1 - alpha) + amp * alpha
vtube.set_mouth(smoothed_amp)
```

### Voice Type Scaling
- **Chatterbox (default)**: Scaling factor 4.0
- **RVC (custom)**: Scaling factor 4.0 (optimized)
- **Normalized audio**: Consistent RMS levels for predictable mouth movement

## Error Handling

### Common Issues and Solutions

#### 1. VTS Connection Failed
**Symptoms:** "VTS not connected; could not send message"
**Solution:**
- Ensure VTube Studio is running
- Check VTS_PORT (default: 8001)
- Verify plugin is enabled

#### 2. RVC Voice Not Found
**Symptoms:** "RVC model files not found"
**Solution:**
- Check if the directory exists
- Ensure it contains `infer.py` and model files
- Verify file permissions

#### 3. Invalid Voice Parameter
**Symptoms:** Error messages about voice validation
**Solution:**
- Use valid RVC model directory
- Directory must contain `infer.py` and model files
- Ensure directory path is correct

#### 4. Mouth Sync Issues
**Symptoms:** Mouth animation not responding
**Solution:**
- Check VTS authentication
- Verify VTS mouth parameter
- Ensure RVC model is loaded

## Advanced Features

### 1. Custom Whisper Models
```bash
python Aivtuber.py --whisper-model small
```

### 2. GPU Acceleration
```bash
pip install torch torchaudio
# Run with CUDA if available
```

### 3. Multi-Character Support
Create separate scripts for different characters:
```bash
# Character 1
python Aivtuber.py --voice ./models/character1_voice

# Character 2
python Aivtuber.py --voice ./models/character2_voice
```

### 4. Real-time Adjustments
```python
# Adjust parameters in Aivtuber.py
silence_threshold = 0.005      # Lower = more sensitive
silence_duration = 1.0        # Seconds of silence before stopping
min_speech_duration = 0.3     # Minimum speech duration to trigger
```

## Troubleshooting

### Q: Why is the mouth sync so slow?
**A:** The current implementation uses exponential smoothing to reduce jitter and ensure smooth animation. This might appear slower but provides better quality.

### Q: How do I use a custom RVC model?
**A:** Download an RVC model from https://github.com/RVC-SFT/SVS, extract it, and provide the directory path with `--voice`.

### Q: What if RVC model is not working?
**A:** If RVC fails to load, the VTuber falls back to Chatterbox TTS. Check if the model directory contains `infer.py` and necessary files.

### Q: Can I use multiple voice models?
**A:** Yes! Each run uses a specific voice model. You can create multiple scripts or modify the code to switch between models.

## Performance Notes

### Audio Processing
- **Block Size**: 256 samples (10.7ms at 24kHz)
- **Smoothing Factor**: 0.7 (balanced responsiveness and smoothness)
- **Update Frequency**: Every 10.7ms

### Memory Usage
- **RVC Model**: 500MB-2GB (depending on model size)
- **Chatterbox**: ~200MB
- **Whisper**: ~500MB (base.en)

### CPU/GPU Requirements
- **CPU**: Supported (slower inference)
- **GPU**: Recommended for RVC and faster Whisper
- **RAM**: 4GB minimum (8GB+ recommended for R

## Future Enhancements

### 1. Multi-Voice Management
- Switch between different voice models during runtime
- Load/save voice configurations
- Voice model hotkeys

### 2. Advanced Emotion System
- More nuanced emotion detection
- Custom emotion triggers
- Voice modulation for emotions

### 3. Stream Processing
- WebSocket streaming for lower latency
- Real-time audio processing
- Live transcription

### 4. Plugin Architecture
- Plugin system for easy feature additions
- Extensible configuration system
- Custom emotion handlers

## License

This project is open source. Feel free to modify and distribute as long as you give appropriate credit.

## Contact

For issues or questions:
- GitHub: https://github.com/your-repo/ai-vtuber
- Email: your-email@example.com
- Discord: your-discord-server

---

## Version History

### Version 1.0 - Initial Release
- Basic Whisper + Chatterbox + VTS integration
- Simple mouth sync
- Auto-configuration

### Version 2.0 - RVC Voice Cloning
- Complete overhaul with RVC
- Professional mouth sync
- Enhanced error handling
- Voice parameter support
- Comprehensive documentation

This implementation represents the most advanced RVC-based VTuber available, combining cutting-edge voice conversion technology with a robust, user-friendly interface.