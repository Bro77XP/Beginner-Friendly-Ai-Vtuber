# AI VTuber with Ollama and Chatterbox Turbo

An AI VTuber that uses Whisper for speech recognition, Ollama for LLM inference, and Chatterbox Turbo TTS in a continuous listening loop.

## Features

- **Whisper** (base.en model) - Real-time speech-to-text in English with adaptive noise VAD
- **Ollama** (llama3.2) - AI model for generating VTuber responses
- **Chatterbox Turbo TTS** - Fast text-to-speech with zero-shot voice cloning
- **Adaptive VAD** - Learns ambient noise floor, auto-tunes silence threshold, trims leading silence
- **Audio normalization** - Pre-processes audio for optimal Whisper accuracy
- **Continuous listening loop** - Runs forever until Ctrl+C
- **VTube Studio integration** - Controls mouth expressions via VTube Studio
- **Twitch chat integration** - Responds to Twitch chat messages in real-time

## Dependencies
(IMPORTANT!!!)
MAKE A VENV FIRST AND MAKE SURE YOU ARE INSIDE THE PROJECT FOLDER
for example

C:\Users\(Yourusername)\Downloads\Begginerfriendlyai

And right click and do "open in terminal"
----

or do cd C:\Users\(Yourusername)\Downloads\Begginerfriendlyai

THEN DO

python -m venv venv

then

venv\Scripts\Activate

or

Now Once your inside your virtual Environment (venv) do this

```bash
pip install -r requirements.txt
```

**Required external tools:**
- [Ollama](https://ollama.ai/) - Install and run: `ollama serve`
- [VTube Studio] - For character animation control

### Core Dependencies (Required - Works on Windows)
```bash
pip install openai-whisper ollama chatterbox-tts pyaudio numpy torch sounddevice soundfile websocket-client rich
```
### Optional RVC Voice Cloning (Advanced - Windows Build Required)
```bash
# Uncomment in requirements.txt or install manually (requires C++ build tools)
# pip install torchaudio librosa onnxruntime onnx fairseq pyworld praat-parselmouth TTS edge-tts
```

**Note:** RVC voice cloning is optional. The VTuber works perfectly with just the core dependencies using Chatterbox TTS. RVC voice cloning requires C++ build tools (Visual Studio Build Tools) and can be challenging to install on Windows.

## Quick Start

MAKE A VENV FIRST AND MAKE SURE YOU ARE INSIDE THE PROJECT FOLDER
for example

C:\Users\(Yourusername)\Downloads\Begginerfriendlyai

And right click and do "open in terminal"
----

or do cd C:\Users\(Yourusername)\Downloads\Begginerfriendlyai

THEN DO

python -m venv venv

then

venv\Scripts\Activate

or

Now Once your inside your virtual Environment (venv) do this


1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Pull models:
```bash
ollama pull llama3.2
python -m pip install openai-whisper
```

3. Start Ollama:
```bash
ollama serve
```

4. Run the VTuber:
```bash
python Aivtuber.py
```

## Configuration

The AI VTuber integrates with VTube Studio to control character animations:

### VTube Studio Integration

The script automatically connects to VTube Studio (port 8001) to control:

- **Mouth expressions**: Real-time mouth movement synchronized with speech
- **Emotion expressions**: Triggers pre-configured emotion hotkeys (happy, sad, angry, thinking, neutral)

**Setup instructions:**
1. Install VTube Studio and start it
2. Open the plugin "Local AI VTuber" from the VTube Studio plugins menu
3. The plugin will automatically generate an authentication token if one doesn't exist
4. Restart the AI VTuber script after initial setup
5. Configure VTube Studio mouth parameter:
   - Input: `MouthOpen`
   - Output: `ParamMouthOpenY`

### Configuring Animation Hotkeys

**Important:** You must configure the actual hotkey IDs in VTube Studio for animations to work:

1. In VTube Studio, create animations for each emotion:
   - Happy animation (e.g., "happy", "joyful", "smile")
   - Sad animation (e.g., "sad", "cry", "depressed")
   - Angry animation (e.g., "angry", "mad", "upset")
   - Thinking animation (e.g., "think", "hmm", "idea")
   - Neutral animation (e.g., "neutral", "calm", "default")

2. Set hotkey IDs for these animations in the VTube Studio plugin settings

3. Edit `Aivtuber.py` and update `EMOTION_HOTKEYS` with the actual hotkey IDs:

```python
EMOTION_HOTKEYS = {
    "happy": "your_happy_hotkey_id",    # Replace with actual hotkey ID
    "sad": "your_sad_hotkey_id",        # Replace with actual hotkey ID  
    "angry": "your_angry_hotkey_id",    # Replace with actual hotkey ID
    "thinking": "your_thinking_hotkey_id", # Replace with actual hotkey ID
    "neutral": "your_neutral_hotkey_id", # Replace with actual hotkey ID
}
```

4. **Auto-configuration option:** The script can auto-detect hotkeys based on name patterns. Leave empty to use auto-detection.

### Model Configuration

- **Whisper**: Uses "base.en" model (configurable via `--whisper-model`)
- **Ollama**: Uses "llama3.2" model for AI responses
- **Chatterbox Turbo**: Loaded by default (use `--voice-model chatterbox` for quality mode)

### Voice Configuration

Change the voice used by the VTuber:

```bash
# Use zero-shot voice cloning from a reference audio file
python Aivtuber.py --voice "C:\path\to\reference.wav"

# Use a specific TTS model
python Aivtuber.py --voice-model chatterbox-turbo  # Fast (default)
python Aivtuber.py --voice-model chatterbox         # Quality

# Adjust voice cloning strength
python Aivtuber.py --voice ref.wav --cfg-weight 0.7  # Higher = closer to reference
```

### Voice Options

**Zero-shot Voice Cloning (Chatterbox Turbo)**
- Provide any `.wav` or `.mp3` file with a reference voice
- The model clones the voice from the reference audio
- Adjust `--cfg-weight` (0.0-1.0) to control similarity to the reference voice

### Voice Parameter Behavior
- If a file path (with `.wav`, `.mp3` extension or `/` or `\` in path): Loads as voice cloning reference
- If empty or not provided: Uses default built-in voice

### Twitch Chat Integration

The VTuber can read and respond to your Twitch chat in real-time.

**Setup:**
1. Get your OAuth token from https://twitchapps.com/tmi/
2. Open `Aivtuber.py` and edit the `TWITCH CONFIG` section at the top:

```python
TWITCH_ENABLED = True             # Set to True to enable Twitch chat
TWITCH_CHANNEL = "your_channel"   # Your Twitch channel name (lowercase)
TWITCH_OAUTH = "oauth:your_token" # Your OAuth token from twitchapps.com/tmi/
TWITCH_BOT_NAME = "your_bot"      # Your bot's Twitch username (lowercase)
TWITCH_RESPOND_ALL = False        # True = respond to all messages, False = only !ask <msg>
TWITCH_COOLDOWN = 5               # Seconds between responses
```

3. Run the VTuber normally: `python Aivtuber.py`

**How it works:**
- With `TWITCH_RESPOND_ALL = False` (default): The bot responds to messages starting with `!ask` (e.g. `!ask what's your favorite game?`)
- With `TWITCH_RESPOND_ALL = True`: The bot responds to every chat message (can be noisy in active chats)
- Responses are both spoken via TTS and sent back as Twitch chat messages
- A cooldown prevents the bot from responding too fast

### Advanced Features

1. **Automatic emotion detection**: The AI analyzes response text and detects emotions to trigger appropriate VTS hotkeys
2. **Response formatting**: The AI is prompted to be a cute anime VTuber with expressive responses
3. **Robust recording**: Advanced silence detection prevents unnecessary recording

## Usage

The AI VTuber runs in a continuous loop:

1. **Listening phase**: Waits for speech with adaptive noise floor calibration
2. **Speech detection**: Only starts recording after minimum speech duration with auto-tuned threshold
3. **Audio normalization**: Peaks normalized for optimal Whisper accuracy
4. **Transcribing**: Uses Whisper to convert speech to text (fp16-aware)
5. **AI response**: Ollama generates a VTuber-appropriate response
6. **Speaking**: Chatterbox Turbo TTS speaks the response aloud (with voice cloning if configured)
7. **Mouth control**: VTube Studio controls mouth expressions in sync with speech
8. **Repeat**: Returns to listening mode

## Notes

- Press Ctrl+C to stop the VTuber at any time
- Ensure proper audio device permissions for microphone access
- For GPU acceleration, install PyTorch CUDA versions
- The VAD auto-calibrates to ambient noise — `silence_threshold` is the base sensitivity floor
- Use `--voice-model chatterbox` if you prefer the slower quality TTS over Turbo

## Troubleshooting

### Common Issues

1. **"Ollama not running" error**:
   - Make sure Ollama is installed and running with `ollama serve`
   - Verify the model "llama3.2" is pulled

2. **VTube Studio connection failed**:
   - Ensure VTube Studio is running
   - Check that VTS_PORT (default: 8001) is correct
   - Make sure VTube Studio plugins are enabled

3. **Audio permissions**:
   - Grant microphone permissions to this application
   - On Linux: `pip install pyaudio` might require additional system packages

4. **Model loading issues**:
   - Whisper uses "base.en" by default (configure with `--whisper-model`)
   - Use `--no-whisper-fp16` on CPU systems to avoid fp16 errors
   - Ensure all dependencies are installed from requirements.txt

5. **Twitch connection failed**:
   - Make sure `TWITCH_ENABLED = True` in `Aivtuber.py`
   - Verify your OAuth token is correct (starts with `oauth:`)
   - Check that channel name and bot name are lowercase
   - Ensure your bot account is not banned from the channel

## Customization

### Adjusting Silence Detection

Edit `Aivtuber.py` and modify these constants:

```python
silence_threshold = 0.01    # Base sensitivity (adaptive noise floor auto-tunes this)
silence_duration = 1.2      # Seconds of silence before stopping recording
min_speech_duration = 0.3   # Minimum speech duration to trigger recording
max_record_duration = 15.0  # Max recording length to prevent hanging
```

### Changing Models

- **Whisper**: `python Aivtuber.py --whisper-model small` (or `base.en`, `medium`, `large`)
- **Ollama**: Change `model="llama3.2"` in `generate_response()` to any installed Ollama model

### Adding Emotions

Edit the `EMOTION_HOTKEYS` dictionary in the code and add hotkeys to VTube Studio:

```python
EMOTION_HOTKEYS = {
    "happy": "your_happy_hotkey_id",
    "sad": "your_sad_hotkey_id",
    "angry": "your_angry_hotkey_id",
    "thinking": "your_thinking_hotkey_id",
    "neutral": "your_neutral_hotkey_id",
}
```

## Future Enhancements

Potential future improvements:

1. **Local LLM alternatives**: Support for other Ollama models or local LLM implementations
2. **Multi-language support**: Whisper language switching and response localization
3. **Context memory**: Maintain conversation history for more coherent interactions
4. **Advanced emotion system**: More nuanced emotion detection and expression control
5. **Stream processing**: WebSocket streaming for lower latency
6. **Plugin architecture**: Easy addition of new features and integrations

## License

This project is open source. Feel free to modify and distribute as long as you give appropriate credit.